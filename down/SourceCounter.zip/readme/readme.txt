Software: SourceCounter
Author: boomworks@hotmail.com
