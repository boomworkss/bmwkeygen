//----------------------------------------------------------------------
BoomWorks.Org Readme file
                                    (C) 1999 - 2011 BoomWorks.Org
//----------------------------------------------------------------------

- Web Site
  http://www.boomworks.org
  http://code.google.com/p/boomworks/

- Web Master E-mail
  BoomWorks@gmail.com

- Shareware/Freeware download list
  http://down.boomworks.org
  http://code.google.com/p/boomworks/downloads/list